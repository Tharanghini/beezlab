/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    static int calang(double hours, double mintz){
        if(hours<0 || mintz<0 || hours>12 || mintz>60){
            System.out.println("invalid");
        }if(hours==12){
            hours=0;
            if(mintz==60){
                mintz=0;
                hours+=1;
                if(hours>12){
                    hours-=12;
                }
            }
        }
        int hang=(int)(0.5*(hours*60 + mintz));
        int mang=(int)(6*mintz);
        int angle=Math.abs(hang - mang);
        angle=Math.min(360-angle, angle);
        return angle;
    }
    
	public static void main(String[] args) {
	    System.out.println(calang(3,30));
	}	
}

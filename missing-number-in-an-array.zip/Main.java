/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    static int missingnum(int a[],int n){
        int i,t;
        t=(n+1)*(n+2)/2;
        for(i=0;i<n;i++){
            t=t-a[i];
        }return t;
    }
    
    
	public static void main(String[] args) {
		int a[]={1,2,3,7,6,8,4};
		int missing= missingnum(a,7);
		System.out.println(missing);
	}
}

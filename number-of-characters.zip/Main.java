/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    String  str="If the bees disappeared off the face of the Earth man would have oonly four years left to live";
		int count=0;
		//int len=str.length();
		for(int i=0;i<str.length();i++){
		    if(str.charAt(i)!=' '){
		        count++;
		    }
		}
		System.out.println("No of characters: "+count);
	}
}
